import cv2
import numpy as np

# Load chessboard image
img = cv2.imread('chessboard.png')

# Define board size and number of tiles
board_size = (8, 8)
tile_size = img.shape[0] // board_size[0]

# Convert image to grayscale and apply thresholding
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)[1]

# Find contours in the thresholded image
contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Initialize tile number and coordinate arrays
tile_nums = np.zeros((board_size[0], board_size[1]), dtype=np.int32)
coords = np.zeros((board_size[0], board_size[1], 2), dtype=np.int32)

# Loop through each contour and classify as pawn or not
for contour in contours:
    # Calculate contour area and perimeter
    area = cv2.contourArea(contour)
    perimeter = cv2.arcLength(contour, True)

    # Check if area or perimeter is too small
    if area < 10 or perimeter < 10:
        # Skip contour if area or perimeter is too small
        continue

    # Calculate compactness (circularity) of contour
    compactness = (4 * np.pi * area) / (perimeter ** 2)

    # Classify contour as pawn if compactness is within a certain range
    if 0.3 <= compactness <= 0.6:
        # Draw bounding rectangle around pawn and highlight in blue
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

        # Calculate tile number and save to array
        tx, ty = x // tile_size, (img.shape[0] - y) // tile_size
        tile_nums[ty, tx] += 1
        coords[ty, tx] = [x + w // 2, y + h // 2]

        # Add tile number to center of tile
        text = f'({tx}, {ty})'
        cv2.putText(img, text, (x + w // 2, y + h // 2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

# Print tile number array and coordinate array
print(tile_nums)
print(coords)

# Show modified image
cv2.imshow('Chessboard', img)
cv2.waitKey(0)
cv2.destroyAllWindows()
